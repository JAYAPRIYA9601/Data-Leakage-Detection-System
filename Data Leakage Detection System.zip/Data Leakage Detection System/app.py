import tkinter as tk
from tkinter import filedialog, messagebox
import sqlite3
import re

# Database setup
def setup_database():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            username TEXT UNIQUE,
            password TEXT
        )
    """)
    conn.commit()
    conn.close()

setup_database()

def register_user():
    email = entry_email.get()
    username = entry_username.get()
    password = entry_password.get()
    confirm_password = entry_confirm_password.get()

    if not email or not username or not password or not confirm_password:
        messagebox.showerror("Error", "All fields are required!")
        return

    if password != confirm_password:
        messagebox.showerror("Error", "Passwords do not match!")
        return

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (email, username, password) VALUES (?, ?, ?)", 
                       (email, username, password))
        conn.commit()
        messagebox.showinfo("Success", "Registration successful! You can now log in.")
        register_window.destroy()
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Email or Username already exists!")
    conn.close()

def login_user():
    global entry_username, entry_password  # Ensure these variables exist
    
    try:
        username = entry_username.get()
        password = entry_password.get()
    except Exception as e:
        messagebox.showerror("Error", "Login fields are missing! Restart the application.")
        return
    
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        login_window.destroy()  # Close login window
        main_application()  # Open main app
    else:
        messagebox.showerror("Error", "Invalid username or password!")


def open_register_window():
    global register_window, entry_email, entry_username, entry_password, entry_confirm_password
    register_window = tk.Toplevel()
    register_window.title("Register")
    register_window.geometry("300x250")
    
    tk.Label(register_window, text="Email").pack()
    entry_email = tk.Entry(register_window)
    entry_email.pack()
    
    tk.Label(register_window, text="Username").pack()
    entry_username = tk.Entry(register_window)
    entry_username.pack()
    
    tk.Label(register_window, text="Password").pack()
    entry_password = tk.Entry(register_window, show="*")
    entry_password.pack()
    
    tk.Label(register_window, text="Confirm Password").pack()
    entry_confirm_password = tk.Entry(register_window, show="*")
    entry_confirm_password.pack()
    
    tk.Button(register_window, text="Register", command=register_user).pack()

def login_page():
    global login_window, entry_username, entry_password
    login_window = tk.Tk()
    login_window.title("Login")
    login_window.geometry("300x200")
    
    tk.Label(login_window, text="Username").pack()
    entry_username = tk.Entry(login_window)
    entry_username.pack()
    
    tk.Label(login_window, text="Password").pack()
    entry_password = tk.Entry(login_window, show="*")
    entry_password.pack()
    
    tk.Button(login_window, text="Login", command=login_user).pack()
    tk.Button(login_window, text="Register", command=open_register_window).pack()
    
    login_window.mainloop()

def main_application():
    root = tk.Tk()
    root.title("Data Leakage Detection System")
    root.geometry("400x250")
    root.configure(bg="#f0f0f0")

    title_label = tk.Label(root, text="Data Leakage Detection", font=("Arial", 14, "bold"), bg="#f0f0f0")
    title_label.pack(pady=20)

    browse_button = tk.Button(root, text="Upload Text File", command=browse_file, font=("Arial", 12), bg="#007bff", fg="white")
    browse_button.pack(pady=10)

    exit_button = tk.Button(root, text="Exit", command=root.quit, font=("Arial", 12), bg="#dc3545", fg="white")
    exit_button.pack(pady=10)

    root.mainloop()

# Define keywords for each category
data_leak_patterns = {
    "Cloud & Online Storage": ["Google Drive", "Dropbox", "OneDrive", "iCloud", "Gmail", "Attachment"],
    "Network-Based Leaks": ["Unsecured Wi-Fi", "MITM Attack", "Remote Desktop Protocol", "Proxy", "VPN Leak"],
    "Messaging Apps & Social Media": ["WhatsApp", "Telegram", "Slack", "Discord", "Signal"],
    "Malware & Cyber Attacks": ["Keylogger", "Spyware", "Ransomware", "Trojan", "Phishing"],
    "Poor Security Configurations": ["Public Database", "Weak Password", "No Encryption", "Open Port", "Admin/Admin"]
}

def detect_leakage(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read()
            
        results = {}
        total_patterns = sum(len(patterns) for patterns in data_leak_patterns.values())
        detected_patterns = 0
        
        for category, patterns in data_leak_patterns.items():
            for pattern in patterns:
                if re.search(rf"\b{pattern}\b", content, re.IGNORECASE):
                    detected_patterns += 1
                    if category not in results:
                        results[category] = []
                    results[category].append(pattern)
        
        accuracy = (detected_patterns / total_patterns) * 100 if total_patterns > 0 else 0
        
        if results:
            result_text = f"Potential Data Leak Detected (Accuracy: {accuracy:.2f}%)\n\n"
            for category, keywords in results.items():
                result_text += f"{category}: {', '.join(keywords)}\n"
            messagebox.showwarning("Alert! Data Leak Detected", result_text)
        else:
            messagebox.showinfo("Safe", f"No data leak detected in the file. (Accuracy: {accuracy:.2f}%)")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to read file: {e}")

def browse_file():
    file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
    if file_path:
        detect_leakage(file_path)

login_page()
